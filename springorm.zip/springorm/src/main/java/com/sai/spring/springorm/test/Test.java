package com.sai.spring.springorm.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sai.spring.springorm.product.dao.ProductDao;
import com.sai.spring.springorm.product.entity.Product;

public class Test {

	public static void main(String[] args) {

		ApplicationContext ap = new ClassPathXmlApplicationContext("com/sai/spring/springorm/test/config.xml");
		ProductDao pd = (ProductDao) ap.getBean("productDaoImpl");
		// Product product = new Product();
		// product.setId(1);
		// product.setName("mobile");
		// product.setDesc("costly");
		// product.setPrice(1000.99);
		// pd.update(product);
		// pd.create(product);
		// pd.delete(product);
		
		//Product product = pd.find(1);
		List<Product> product = pd.findAll();
		System.out.println(product);
	}

}
